﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using Nary Tree;

namespace Test
{
    public class Nary test
    {
        public void Test_constuction();
        {
        //Boom initialiseren
        var Boom = new Boom<int>();

        //test waardes initialiseren
        var TopBoom = Boom.VoegKindToe(null, 10);
        var Node1 = Boom.VoegKindToe(TopBoom, 5);

        //Testen
        Assert.Multiple(() =>
        {
            Assert.That(Node1.Papa.Value == 10); //Checken of papa node1 gelijk is aan ingevulde waarde
            Assert.Contains(Node1, Boom.DeBoom); //Checken of Node1 in boom zit
            Assert.Contains(TopBoom, Boom.DeBoom); //Checken of TopNode erin zit
        })

        }
        
        public void Test_Del();
        {
            //Initialiseren
            var Boom = new Boom<int>();
            var TopNode = Boom.VoegKindToe(null, 10);
            var Node1 = Boom.VoegKindToe(TopBoom, 5);
            var Node2 = Boom.VoegKindToe(TopBoom, 8);

            //Delete
            Boom.VerwijderNode(Node2);

            //Check
            
        }

        public void Test_Sum();
        {
         //Initialiseren
        var Boom = new Boom<int>();
        var TopNode = Boom.VoegKindToe(null, 10);
        var Node1 = Boom.VoegKindToe(TopBoom, 5);
        var Node2 = Boom.VoegKindToe(Node1, 8);

        //sommeren
        List<int> sommatie = Boom.SumLeafs();
        
        //check
        Assert.AreEqual(23, sommatie[0]);
        }
    }
}
