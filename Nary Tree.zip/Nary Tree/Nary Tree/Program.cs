﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nary_Tree
{
    public class BoomNode<T>
    {
        public T Value { get; set; }
        public List<BoomNode<T>> Child { get; set; }
        public BoomNode<T> Papa { get; set; } 

        public BoomNode(T value, BoomNode<T> papa)
        {
            Value = value;
            Papa = papa;
            Child = new List<BoomNode<T>>();
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            //Hierin Testen we het programma met enkele waardes
            var Boom = new Boom<int>(); //De boom initialiseren

            //TopNode van boom maken
            var TopNode = Boom.VoegKindToe(null, 1); //null omdat deze geen vader heeft
            //Paar Test Nodes aanmaken
            var Node11 = Boom.VoegKindToe(TopNode, 8);
            var Node21 = Boom.VoegKindToe(TopNode, 3);
            var Node31 = Boom.VoegKindToe(TopNode, 23);
            var Node121 = Boom.VoegKindToe(Node11, 2);
            var Node122 = Boom.VoegKindToe(Node11, 5);

            //Node verwijderen
            Boom.VerwijderNode(Node122);

            //Print Nodes
            //List<int> values = Boom.TraverseNodes();
            //for(int i=0; i < values.Count;i++)
            //{
              //  Console.WriteLine(values[i]);
            //}

            //Print Sommaties
            List<int> Sommaties = Boom.SumLeafs();
            for(int i=0; i<Sommaties.Count;i++)
            {
                Console.WriteLine(Sommaties[i]);

            }
            
            Console.ReadLine();

        }
    }
}
