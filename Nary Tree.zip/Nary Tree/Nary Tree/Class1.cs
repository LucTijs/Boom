﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nary_Tree
{
    public class Boom<T>
    {
        public int Count { get; set; }
        public int LeafCount { get; set; }

        public List<BoomNode<T>> DeBoom = new List<BoomNode<T>>(); // Definieren als lijst van Nodes

        public Boom()
        {
            Count = 0; // Aantal Nodes in de Tree, Begin waarden op 0 instellen
            LeafCount = 0; //Aantal leafs onderin
        }

        //Nodes toevoegen aan de boom
        public BoomNode<T> VoegKindToe(BoomNode<T> vaderNode, T value)
        {
            Count++; //Aantal Nodes verhogen
            BoomNode<T> nieuwNode = new BoomNode<T>(value, vaderNode);
            //Check if node has a parent, add node to the tree
            if (vaderNode != null) //Null dan is het een 'Vader' Node
            {
                DeBoom.Add(nieuwNode);
                vaderNode.Child.Add(nieuwNode);
            }
            else //Anders kan deze gewoon toegevoegd worden met de ingevulde vaderNode
            {
                DeBoom.Add(nieuwNode);

            }

            LeafCount = 0;
            foreach (BoomNode<T> leaf in DeBoom) //Loopen over alle Nodes
            {
                if (leaf.Child.Count == 0) //Alle nodes zonder kinderen zitten onderaan en dus kan de leafcount geupdated worden.
                {
                    LeafCount++;
                }
            }
            return nieuwNode;
        }

        //Nodes Verwijderen
        public void VerwijderNode(BoomNode<T> node)
        {
            DeBoom.Remove(node); //Uit DE boom verwijderen zoals de functie al zegt
            Count--; //Count met 1 verlagen
            node.Papa.Child.Remove(node); // Verwijder kind van Papa Node

            //Alle kinderen verwijderen
            if (node.Child.Count != 0)// controleren of er 'kinderen' zijn( bij 0 kinderen dus niet)
            {
                for (int i = node.Child.Count - 1; i >= 0; i--) //loopen over de 'kinderen'
                {
                    VerwijderNode(node.Child[i]);
                }
            }

            //Leafcount updaten
            LeafCount = 0;
            foreach (BoomNode<T> leaf in DeBoom)
            {
                if (leaf.Child.Count == 0) //Zelfde verhaal als bij toevoegen
                {
                    LeafCount++;
                }
            }
        }

        //Add nodes waardes in een lijst zetten
        public List<T> TraverseNodes()
        {
            List<T> traversednodes = new List<T>();

            foreach (BoomNode<T> node in DeBoom) // Loopen over alle nodes
            {
                traversednodes.Add(node.Value); //Waarde ervan pakken
            }
            return traversednodes; //Lijst terug geven met alle waardes van de nodes
        }

        public List<T> SumLeafs() //Som van weg naar alle leafs berekenen
        {
            List<T> Sumleafs = new List<T>(); //
            List<BoomNode<T>> AllLeafs = new List<BoomNode<T>>(); //Lijst met alle leafs
            foreach (BoomNode<T> nodes in DeBoom) //Loopen over alle Nodes
            {
                if (nodes.Child.Count == 0) //Als Node geen kinderen heeft is het een leaf en dus toevoegen aan lisjt
                {
                    //Toevoegen aan lijst
                    BoomNode<T> Papa = nodes;
                    //Console.WriteLine(nodes.Value);
                    dynamic Sum = 0; //Dynamic want type 'T' en int/double kunnen niet opgeteld worden
                    Sum = Sum + Papa.Value;
                    while (Papa.Papa != null) //Omhoog blijven gaan tot je bovenaan bent
                    {
                        Sum = Sum + Papa.Papa.Value; //Waarde van papa node toevoegen
                        Papa = Papa.Papa; //Papa nodes updaten
                    }
                    Sumleafs.Add(Sum); //Lijst vullen met alle leafs(met waardes ervan)
                    Console.WriteLine(Sum);
                }
            }

            return Sumleafs;
        }


    }

}
